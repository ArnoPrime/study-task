﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Onlyblog
{
    public partial class ListArticle : System.Web.UI.Page
    {
        BLL.index index = new BLL.index();
        protected void Page_Load(object sender, EventArgs e)
        {
            bind();
        }

        public void bind()
        {
            index.artc = new Model.article();
            index.artc.Atid = Convert.ToInt32(Request.QueryString["Tid"]);
            this.BlogList.DataSource = index.dstype();
            this.BlogList.DataBind();
        }
        protected void BlogList_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "delete")
            {
                index.artc = new Model.article();
                index.artc.Aid = (Convert.ToInt32(e.CommandArgument.ToString()));
                SqlDataReader read = index.DataReader();
                if (read.HasRows)
                {
                    read.Close();
                    string uid = index.Uid();
                    if (Session["Uid"]!=null&&Session["Uid"].ToString()== uid)
                    {
                        if (index.delete())
                        {
                            Response.Write("<script>alert('删除成功！')</script>");
                        }
                        else
                        {
                            Response.Write("<script>alert('删除失败！')</script>");
                        }
                    }
                }
                else
                {
                    Response.Write("<script>alert('您没有权限删除！')</script>");
                }
            }
        }
    }
}