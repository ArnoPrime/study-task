﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Onlyblog
{
    public partial class blogindex : System.Web.UI.Page
    {
        BLL.index index = new BLL.index();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.bind();
            }
        }

        public void bind()
        {
            index.artc = new Model.article();
            index.artc.Auserid = Convert.ToInt32(Session["UserID"]);
            if (index.artc.Auserid ==0)
            {
                this.NewsList.DataSource = index.dsall();
                this.NewsList.DataBind();
              
            }
            else
            {
                this.NewsList.DataSource = index.dsuser();
                this.NewsList.DataBind();
            }
        }

        #region 将长的字符串替换为“…”
        public string SubStr(string sString, int nLeng)
        {
            if (sString.Length <= nLeng)
            {
                return sString;
            }
            string sNewStr = sString.Substring(0, nLeng);
            sNewStr = sNewStr + "...";
            return sNewStr;
        }
        #endregion
        protected void NewsList_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            NewsList.PageIndex = e.NewPageIndex;
            bind();
        }
    }
}