﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace Onlyblog
{
    public partial class AddArticle : System.Web.UI.Page
    {
        BLL.Article Artc = new BLL.Article();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            this.FileUpload1.Visible = true;
        }

        protected void btnfabiao_Click(object sender, EventArgs e)
        {
            Artc.atcl = new Model.article();
            Artc.atcl.Aname = this.txtAname.Text;
            Artc.atcl.Atime = DateTime.Now.ToLocalTime().ToString();
            Artc.atcl.Atid = Convert.ToInt32(this.dpltype.SelectedValue);
            Artc.atcl.Adetail = this.CKEditorControl1.Text;
            Artc.atcl.Auserid = Convert.ToInt32(Session["Uid"]);
            //Artc.atcl.Auserid = 1;
            if (this.FileUpload1.Visible == true)
            {
                #region 图片上传
                string fullpath = this.FileUpload1.PostedFile.FileName;
                string filename = Path.GetFileName(fullpath);
                string savepath = Server.MapPath("image" + "//" + filename);
                this.FileUpload1.PostedFile.SaveAs(savepath);
                Artc.atcl.Aimg = filename;
                if (Artc.addArticle() == true)
                {
                    Response.Write("<script>alert('发表成功！')</script>");
                }
                else
                {
                    Response.Write("<script>alert('发表失败，请检查问题！')</script>");
                }
                #endregion
            }
            else
            {
                if (Artc.addArticlenoimg() == true)
                {
                    Response.Write("<script>alert('发表成功！')</script>");
                }
                else
                {
                    Response.Write("<script>alert('发表失败，请检查问题！')</script>");
                }
            }
        }

        protected void btnclear_Click(object sender, EventArgs e)
        {
            this.txtAname.Text = "";
            this.CKEditorControl1.Text = "";
        }
    }
}