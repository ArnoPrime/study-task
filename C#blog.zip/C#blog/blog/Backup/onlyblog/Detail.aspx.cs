﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace Onlyblog
{
    public partial class Detail : System.Web.UI.Page
    {
        BLL.Article art = new BLL.Article();

        protected void Page_Load(object sender, EventArgs e)
        {
            bind();
        }

        public void bind()
        {
            art.atcl = new Model.article();
            art.atcl.Aid = Convert.ToInt32(Request.QueryString["Aid"]);
            //art.atcl.Aid = 1;
            DataSet ds = art.ArticlDetail();
            this.td1.InnerHtml = ds.Tables["result"].Rows[0][1].ToString();
            this.td2.InnerHtml = "时间：" + ds.Tables["result"].Rows[0][4].ToString();
            this.td3.InnerHtml = ds.Tables["result"].Rows[0][2].ToString();
            DataSet ds2 = art.ArticlComment();
            if (ds2.Tables["result"].Rows.Count>0)
            {
                this.pingllun.Visible = false;
                this.dlpingl.DataSource = ds2;
                this.dlpingl.DataBind();
            }
            else
            {
                this.pinglun0.Visible = false;
            }
        }

        protected void btncomment_Click(object sender, EventArgs e)
        {
            art.Users = new Model.Users();
            art.comment = new Model.comment();
            if (Session["Uid"] == null)
            {
                Response.Write("<script>alert('请登录后评论')</script>");
            }
            else
            {
                art.Users.Uid = Convert.ToInt32(Session["Uid"]);
                //art.Users.Uid = 1;
                art.comment.Cdetail = this.txtcomment.Text;
                art.comment.Ctime = DateTime.Now.ToLocalTime().ToString();
                art.comment.CAid = Convert.ToInt32(Request.QueryString["Aid"]);
                //art.comment.CAid = 1;
                if (art.AddComment())
                {
                    this.txtcomment.Text = "";
                    this.bind();
                }
                else
                {

                }
            }
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            art.atcl = new Model.article();
            art.atcl.Aid = Convert.ToInt32(Request.QueryString["Aid"]);
            //art.atcl.Aid = 1;
            Response.Redirect("/EditArticle.aspx?Aid=" + art.atcl.Aid);
        }
    }
}