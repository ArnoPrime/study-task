﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace Onlyblog
{
    public partial class Register : System.Web.UI.Page
    {
        int a;//用于保存返回值。返回值为-1（用户名存在），0（失败），1（成功），2（用户名不存在）
        BLL.Register Regist = new BLL.Register();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtLoginName_TextChanged(object sender, EventArgs e)
        {
            check();
            if (a == -1)
            {
                Label2.Text = "<font color=\"red\" size=\"2\">用户名已经存在</font>";
                txtname.Text = "";
                return;
            }
            else if (a == 2)
            {
                Label2.Text = "<img src=\"image/greentick.png\" />";
            }
        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            Regist.Users = new Model.Users();
            Regist.Users.Uname = this.txtname.Text;
            Regist.Users.Upwd = Regist.GetMD5(txtPwd.Text.ToString());
            #region 图片
            string fullpath = this.FileUpload1.PostedFile.FileName;
            string filename = Path.GetFileName(fullpath);
            string savepath = Server.MapPath("image//"+filename);
            this.FileUpload1.PostedFile.SaveAs(savepath);
            #endregion
            //Regist.Users.Uimg
            Regist.Users.Uimg = filename;
            if (Regist.InsertUser())
            {
                Response.Redirect("blogindex.aspx");
            }
            else
            {
                Response.Write("<script>alert('很遗憾出错了！')</script>");
            }
        }

        protected void btncz_Click(object sender, EventArgs e)
        {

        }

        public int check()
        {
            Regist.Commonality = new Model.Commonality();
            Regist.Commonality.CheckName = this.txtname.Text.Trim();
            a = Regist.CheckName();
            return a;
        }
    }
}