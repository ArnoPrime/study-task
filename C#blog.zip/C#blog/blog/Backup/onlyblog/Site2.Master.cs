﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Onlyblog
{
    public partial class Site2 : System.Web.UI.MasterPage
    {
        BLL.Register logins = new BLL.Register();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Uid"] == null)
            {
                this.Lable.Visible = false;
                this.content.Visible = false;
            }
            else
            {
                this.login.Visible = false;
                this.login2.Visible = true;
                this.lbuname.Text = Session["Uname"].ToString();
                logins.Users = new Model.Users();
                logins.Users.Uid = Convert.ToInt32(Session["Uid"]);
                string img = logins.Uimg();
                this.Lable.Visible = true;
                this.content.Visible = true;
                this.imguser.ImageUrl = "~/Image/" + img;
            }
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            logins.Users = new Model.Users();
            logins.Users.Uname = this.txtname.Text;
            logins.Users.Upwd = logins.GetMD5(this.txtpwd.Text);
            SqlDataReader read1 = logins.DataReader();
            if (read1.HasRows)
            {
                Session["Uname"] = this.txtname.Text;
                read1.Close();
                Session["Uid"] = logins.Uid();
                logins.Users.Uid = Convert.ToInt32(Session["Uid"]);
                string img = logins.Uimg();
                this.lbuname.Text = this.txtname.Text;
                this.login.Visible = false;
                this.login2.Visible = true;
                this.Lable.Visible = true;
                this.content.Visible = true;
                this.imguser.ImageUrl = "~/Image/" + img;
            }
        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }
    }
}