﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class DB
    {
        protected SqlConnection conn;
        protected string conStr;
        public DB()
        {
            conStr = "Data Source=DESKTOP-FP2HTFO;Initial Catalog=blog;uid=sa;pwd=123456";
        }
        #region 连接和关闭
        private void Open()                          //定义一个私有方法，防止外界访问
        {
            if (conn == null)                        //判断数据库连接是否存在
            {
                conn = new SqlConnection(conStr);    //不存在，新建数据库连接
                conn.Open();                         //打开数据库连接
            }
            else
            {
                if (conn.State.Equals(ConnectionState.Closed))//存在，判断是否关闭
                    conn.Open();                             //连接处于关闭状态，重新打开
            }
        }
        public void Close()                                 //定义一个公有方法，关闭数据库连接
        {
            if (conn.State.Equals(ConnectionState.Open))
            {
                conn.Close();                               //连接处于打开状态，关闭连接
            }
        }
        #endregion

        #region 析构函数，释放非托管资源
        public void Dispose()
        {
            if (conn != null)
            {
                conn.Dispose();
                conn = null;
            }
        }
        /// <summary>
        /// 析构函数，释放非托管资源
        /// </summary>
        ~DB()
        {
            try
            {
                if (conn != null)
                    conn.Close();
            }
            catch { }
            try
            {
                Dispose();                                //释放占有资源
            }
            catch { }
        }
        #endregion

        #region  执行SQL语句，返回布尔值
        /// <summary>
        /// 此方法用来执行SQL语句
        /// </summary>
        /// <param name="SqlCom">要执行的SQL语句</param>
        /// <returns></returns>
        public bool ExceSql(string strSqlCom)
        {
            Open();
            SqlCommand sqlcom = new SqlCommand(strSqlCom, conn);
            try
            {
                sqlcom.ExecuteNonQuery();                       //执行添加操作的SQL语句
                return true;
            }
            catch
            {
                return false;                                   //执行SQL语句失败，返回false
            }
            finally
            {
                Close();
            }
        }
        #endregion

        #region 返回一个SqlDataReader类型的参数
        /// <summary>
        /// 此方法返回一个SqlDataReader类型的参数
        /// </summary>
        /// <param name="SqlCom">需要执行的Sql语句</param>
        /// <returns>返回一个SqlDataReader类型的参数</returns>
        public SqlDataReader ExceRead(string sqlCom)
        {
            Open();                                            //打开数据库连接
            SqlCommand com = new SqlCommand(sqlCom, conn);      //创建命令对象
            SqlDataReader read = com.ExecuteReader();
            return read;
        }
        #endregion

        #region  返回一个字符串
        /// <summary>
        /// 返回一个字符串
        /// </summary>
        /// <param name="read"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public string ExceString(SqlDataReader read, string name)
        {
            Open();
            read.Read();
            string a = read[name].ToString();
            read.Close();
            return a;
        }
        #endregion

        #region 返回一个DataSet
        /// <summary>
        /// 返回一个DataSet
        /// </summary>
        /// <param name="strsql">需要执行的SQL语句</param>
        /// <param name="tbname"></param>
        /// <returns></returns>
        //public DataSet FillDataset(string strsql)
        public DataSet FillDataset(string strsql)
        {
            Open();
            SqlDataAdapter da = new SqlDataAdapter(strsql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "result");
            return ds;
        }
        #endregion

        #region 参数传值方法，防止SQL注入式攻击
        /// <summary>
        /// 参数传值方法，防止SQL注入式攻击
        /// </summary>
        public int checkLogin(string loginName, string loginPwd)
        {
            string strsql = "select count(*) from Users where UserName=@UserName and PassWord=@PassWord";
            Open();
            SqlCommand sqlcom = new SqlCommand(strsql, conn);
            sqlcom.Parameters.Add(new SqlParameter("@UserName", SqlDbType.NVarChar, 50));
            sqlcom.Parameters["@UserName"].Value = loginName;
            sqlcom.Parameters.Add(new SqlParameter("@PassWord", SqlDbType.NVarChar, 50));
            sqlcom.Parameters["@PassWord"].Value = loginPwd;
            int i = (int)sqlcom.ExecuteScalar();
            Close();
            return i;
        }
        #endregion

        #region 返回DataTable数据表
        /// <summary>
        /// 执行SQL查询语句
        /// </summary>
        /// <param name="cmdstr">查询语句</param>
        /// <returns>返回DataTable数据表</returns>
        public DataTable reDt(string cmdstr)
        {
            Open();
            SqlDataAdapter da = new SqlDataAdapter(cmdstr, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return (ds.Tables[0]);
        }
        #endregion
    }
}
