﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace BLL
{
    public class index
    {
        DAL.DB db = new DAL.DB();
        public Model.article artc;
        public DataSet dsuser()
        {
            string sql = "select * from article where"+artc.Auserid;
            return db.FillDataset(sql);
        }

        public DataSet dsall()
        {
            string sql = "select * from article ";
            return db.FillDataset(sql);
        }

        public DataSet dstype()
        {
            string sql = "select * from article where Atid=" + artc.Atid;
            return db.FillDataset(sql);
        }

        public string Uid()
        {
            string sql="select * from article where Aid="+artc.Aid;
             SqlDataReader read = db.ExceRead(sql);
             return db.ExceString(read, "Auserid");
        }

        public bool delete()
        {
            string sql = "delete from article where Aid="+artc.Aid;
            return db.ExceSql(sql);
        }

        public SqlDataReader DataReader()
        {
            string sql = "select * from article where Aid='" + artc.Aid+"'";
            return db.ExceRead(sql);
        }
        #region 截取字符串
        /// 名称：FixLengthString 
        /// 功能：截取指定长度的字符串 
        /// <param name="oText">源文本</param>
        /// <param name="length">截取的长度</param>
        /// <returns>按长度截取后的字符串</returns>
        /// </summary> 
        public static string FixLengthString(string oText, int length)
        {
            string returnString = oText.Length > length ? oText.Substring(0, length) : oText;
            return returnString;
        }
        #endregion

        #region 去掉html标记
        public static string NoHTML(string Htmlstring)
        {
            //Regex.Replace从输入字符串中的第一个字符开始，用指定的替换字符串替换由指定的正则表达式定义的模式的所有匹配项。可指定选项来修改匹配的行为。
            Regex htmlReg = new Regex(@"<[^>]+>", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            Regex htmlSpaceReg = new Regex("\\&nbsp\\;", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            Regex spaceReg = new Regex("\\s{2,}|\\ \\;", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            Regex styleReg = new Regex(@"<style(.*?)</style>", RegexOptions.Compiled | RegexOptions.IgnoreCase);
            //删除脚本
            Regex scriptReg = new Regex(@"<script(.*?)</script>", RegexOptions.Compiled | RegexOptions.IgnoreCase);

            Htmlstring = styleReg.Replace(Htmlstring, string.Empty);
            Htmlstring = scriptReg.Replace(Htmlstring, string.Empty);
            Htmlstring = htmlReg.Replace(Htmlstring, string.Empty);
            Htmlstring = htmlSpaceReg.Replace(Htmlstring, " ");
            Htmlstring = spaceReg.Replace(Htmlstring, " ");
            return Htmlstring.Trim();
        }
        #endregion
    }
}
