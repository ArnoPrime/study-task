﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
    public class Register
    {
        public Model.Users Users;
        public Model.Commonality Commonality;
        DAL.DB db = new DAL.DB();
        #region 检查用户名是否存在
        /// <summary>
        /// 检查用户名是否存在
        /// </summary>
        /// <returns></returns>
        public int CheckName()
        {
            string sql = "select count(*) from Users where Uname='" + Commonality.CheckName + "'";
            DataTable dt = db.reDt(sql);
            if (dt.Rows[0][0].ToString() != "0")
            {
                return -1;
            }
            else
            {
                return 2;
            }
        }
        #endregion
        #region MD5加密
        /// <summary>
        /// MD5加密
        /// </summary>
        /// <param name="strPwd"></param>
        /// <returns></returns>
        public string GetMD5(string strPwd)
        {
            string pwd = "";
            //实例化一个md5对象
            MD5 md5 = MD5.Create();
            // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择
            byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(strPwd));
            //翻转生成的MD5码        
            s.Reverse();
            //通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
            //只取MD5码的一部分，这样恶意访问者无法知道取的是哪几位
            for (int i = 3; i < s.Length - 1; i++)
            {
                //将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符
                //进一步对生成的MD5码做一些改造
                pwd = pwd + (s[i] < 198 ? s[i] + 28 : s[i]).ToString("X");
            }
            return pwd;
        }
        #endregion

        public bool InsertUser()
        {
            string sql = "INSERT INTO [blog].[dbo].[Users]([Uname],[Upwd],[Uimg])VALUES('"+Users.Uname+"','"+Users.Upwd+"','"+Users.Uimg+"')";
            return db.ExceSql(sql);
        }

        public SqlDataReader DataReader()
        {
            string sql = "select * from Users where Uname='" + Users.Uname + "'and Upwd='" + Users.Upwd + "'";
            return db.ExceRead(sql);
        }

        //读取用户ID
        public String Uid()
        {
            string sql = "select * from Users where Uname='" + Users.Uname + "'";
            SqlDataReader read = db.ExceRead(sql);
            return db.ExceString(read, "Uid");
        }

        //读取用户图片
        public String Uimg()
        {
            string sql = "select * from Users where Uid='" + Users.Uid + "'";
            SqlDataReader read = db.ExceRead(sql);
            return db.ExceString(read, "Uimg");
        }
    }
}
