﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
    public class Article
    {
        DAL.DB db = new DAL.DB();
        public Model.article atcl = new Model.article();
        public Model.comment comment = new Model.comment();
        public Model.Users Users = new Model.Users();
        public bool addArticlenoimg()
        {
            string sql = "INSERT INTO [blog].[dbo].[article]([Aname],[Adetail],[Atime],[Auserid],[Atid])VALUES('" + atcl.Aname + "','" + atcl.Adetail + "','" + atcl.Atime + "','" + atcl.Auserid + "','" + atcl.Atid + "')";
            return db.ExceSql(sql);
        }
        public bool addArticle()
        {
            string sql = "INSERT INTO [blog].[dbo].[article]([Aname],[Adetail],[Aimg],[Atime],[Auserid],[Atid])VALUES('" + atcl.Aname + "','" + atcl.Adetail + "','" + atcl.Aimg + "','" + atcl.Atime + "','" + atcl.Auserid + "','" + atcl.Atid + "')";
            return db.ExceSql(sql);
        }

        public bool editArticle()
        {
            string sql = "UPDATE [blog].[dbo].[article]SET [Aname] = '" + atcl.Aname + "',[Adetail] = '" + atcl.Adetail + "',[Aimg] = '" + atcl.Aimg + "',[Atime] = '" + atcl.Atime + "', [Atid] = '" + atcl.Atid + "'WHERE  [Aid] =" + atcl.Aid;
            return db.ExceSql(sql);
        }

        public bool editArticlenoimg()
        {
            string sql = "UPDATE [blog].[dbo].[article]SET [Aname] = '" + atcl.Aname + "',[Adetail] = '" + atcl.Adetail + "',[Atime] = '" + atcl.Atime + "', [Atid] = '" + atcl.Atid + "'WHERE  [Aid] = " + atcl.Aid;
            return db.ExceSql(sql);
        }

        public DataSet ArticlDetail()
        {
            string sql = "select * from article where Aid=" + atcl.Aid;
            return db.FillDataset(sql);
        }

        public DataSet ArticlComment()
        {
            string sql = "select * from comment,Users where CAid=" + atcl.Aid + " and comment.Cuserid=Users.Uid ";
            return db.FillDataset(sql);
        }

        public string Cid()
        {
            string sql = "select * from comment,Users where CAid=" + atcl.Aid + " and comment.Cuserid=Users.Uid";
            SqlDataReader read = db.ExceRead(sql);
            return db.ExceString(read, "Cid");
        }

        public bool AddComment()
        {
            string sql = "INSERT INTO [blog].[dbo].[comment]([Cuserid],[Cdetail],[Ctime],[CAid])VALUES(" + Users.Uid + ",'" + comment.Cdetail + "','" + comment.Ctime + "','" + comment.CAid + "')";
            return db.ExceSql(sql);
        }

        //public DataSet 
    }
}
