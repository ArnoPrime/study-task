﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

namespace Onlyblog
{
    public partial class EditArticle : System.Web.UI.Page
    {
        BLL.Article Artc = new BLL.Article();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Bind();
            }
        }

        public void Bind()
        {
            Artc.atcl = new Model.article();
            Artc.atcl.Aid = Convert.ToInt32(Request.QueryString["Aid"]);
            //Artc.atcl.Aid = 1;
            DataSet ds = new DataSet();
            ds = Artc.ArticlDetail();
            this.txtAname.Text = ds.Tables["result"].Rows[0][1].ToString();
            this.txtText.Text = ds.Tables["result"].Rows[0][2].ToString();

        }
        protected void btnfabiao_Click(object sender, EventArgs e)
        {
            Artc.atcl = new Model.article();
            Artc.atcl.Aid = Convert.ToInt32(Request.QueryString["Aid"]);
            //Artc.atcl.Aid = 1;
            Artc.atcl.Aname = this.txtAname.Text;
            Artc.atcl.Atime = DateTime.Now.ToLocalTime().ToString();
            Artc.atcl.Atid = Convert.ToInt32(this.dpltype.SelectedValue);
            Artc.atcl.Adetail = this.txtText.Text;
            //Artc.atcl.Auserid = Convert.ToInt32(Session["UserID"]);
            Artc.atcl.Auserid = 1;
            if (this.FileUpload1.Visible == true)
            {
                #region 图片上传
                string fullpath = this.FileUpload1.PostedFile.FileName;
                string filename = Path.GetFileName(fullpath);
                string savepath = Server.MapPath("image" + "//" + filename);
                this.FileUpload1.PostedFile.SaveAs(savepath);
                Artc.atcl.Aimg = filename;
                if (Artc.editArticle() == true)
                {
                    Response.Write("<script>alert('发表成功！')</script>");
                }
                else
                {
                    Response.Write("<script>alert('发表失败，请检查问题！')</script>");
                }
                #endregion
            }
            else
            {
                if (Artc.editArticlenoimg()== true)
                {
                    Response.Write("<script>alert('发表成功！')</script>");
                }
                else
                {
                    Response.Write("<script>alert('发表失败，请检查问题！')</script>");
                }
            }
        }

        protected void btnclear_Click(object sender, EventArgs e)
        {
            this.txtAname.Text = "";
            this.txtText.Text = "";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            this.FileUpload1.Visible = true;
        }
    }
}