﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Model
{
    public class Commonality
    {
        public Commonality()
        { }
        #region Model
        private string search;
        /// <summary>
        /// 
        /// </summary>
        public string Search
        {
            set { search = value; }
            get { return search; }
        }
        private string checkName;
        /// <summary>
        /// 
        /// </summary>
        public string CheckName
        {
            set { checkName = value; }
            get { return checkName; }
        }
        #endregion Model
    }
}
