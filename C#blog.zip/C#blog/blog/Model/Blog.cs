﻿using System;
namespace Blog.Model
{
	/// <summary>
	/// Blog:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class Blog
	{
		public Blog()
		{}
		#region Model
		private string _bimg;
		private int _buid;
		/// <summary>
		/// 
		/// </summary>
		public string Bimg
		{
			set{ _bimg=value;}
			get{return _bimg;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int Buid
		{
			set{ _buid=value;}
			get{return _buid;}
		}
		#endregion Model

	}
}

