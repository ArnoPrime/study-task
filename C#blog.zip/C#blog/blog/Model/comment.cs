﻿using System;
namespace Model
{
	/// <summary>
	/// comment:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class comment
	{
		public comment()
		{}
		#region Model
		private int _cid;
		private int? _cuserid;
		private string _cdetail;
		private string _ctime;
        private int _caid;
		/// <summary>
		/// 
		/// </summary>
		public int Cid
		{
			set{ _cid=value;}
			get{return _cid;}
		}
        /// <summary>
        /// 
        /// </summary>
        public int CAid
        {
            set { _caid = value; }
            get { return _caid; }
        }
		/// <summary>
		/// 
		/// </summary>
		public int? Cuserid
		{
			set{ _cuserid=value;}
			get{return _cuserid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Cdetail
		{
			set{ _cdetail=value;}
			get{return _cdetail;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Ctime
		{
			set{ _ctime=value;}
			get{return _ctime;}
		}
		#endregion Model

	}
}

