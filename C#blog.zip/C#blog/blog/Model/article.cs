﻿using System;
namespace Model
{
	/// <summary>
	/// article:实体类(属性说明自动提取数据库字段的描述信息)
	/// </summary>
	[Serializable]
	public partial class article
	{
		public article()
		{}
		#region Model
		private int _aid;
		private string _aname;
		private string _adetail;
		private string _aimg;
		private string _atime;
		private int? _auserid;
		private int? _atid;
		/// <summary>
		/// 
		/// </summary>
		public int Aid
		{
			set{ _aid=value;}
			get{return _aid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Aname
		{
			set{ _aname=value;}
			get{return _aname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Adetail
		{
			set{ _adetail=value;}
			get{return _adetail;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Aimg
		{
			set{ _aimg=value;}
			get{return _aimg;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Atime
		{
			set{ _atime=value;}
			get{return _atime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? Auserid
		{
			set{ _auserid=value;}
			get{return _auserid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? Atid
		{
			set{ _atid=value;}
			get{return _atid;}
		}
		#endregion Model

	}
}

