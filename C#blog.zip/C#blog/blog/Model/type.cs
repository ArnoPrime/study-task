﻿using System;
namespace Blog.Model
{
	/// <summary>
	/// 1
	/// </summary>
	[Serializable]
	public partial class type
	{
		public type()
		{}
		#region Model
		private int _tid;
		private string _tname;
		/// <summary>
		/// 
		/// </summary>
		public int Tid
		{
			set{ _tid=value;}
			get{return _tid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Tname
		{
			set{ _tname=value;}
			get{return _tname;}
		}
		#endregion Model

	}
}

