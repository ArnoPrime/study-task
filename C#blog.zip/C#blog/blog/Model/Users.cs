﻿using System;
namespace Model
{
	/// <summary>
	/// 1
	/// </summary>
	[Serializable]
	public partial class Users
	{
		public Users()
		{}
		#region Model
		private int _uid;
		private string _uname;
		private string _upwd;
		private string _uimg;
		/// <summary>
		/// 
		/// </summary>
		public int Uid
		{
			set{ _uid=value;}
			get{return _uid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Uname
		{
			set{ _uname=value;}
			get{return _uname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Upwd
		{
			set{ _upwd=value;}
			get{return _upwd;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Uimg
		{
			set{ _uimg=value;}
			get{return _uimg;}
		}
		#endregion Model

	}
}

